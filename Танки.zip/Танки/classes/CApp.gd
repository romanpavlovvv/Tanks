extends Node

# флаг загрузки данных для сцен
var _is_loaded_scene: bool = false;

# контроль первого игрока 
var control_1: CControl;

# контроль второго игрока 
var control_2: CControl;

# сетка
var grid: CGrid;

# темп
var tmp: CTmp;

# audio
var audio: CAudio;

# громкость
var volume: float = 0;

# узел готов 

func _ready() -> void:
	
	#Input.set_mouse_mode(Input.MOUSE_MODE_HIDDEN)
	
	set_pause_mode(PAUSE_MODE_PROCESS);
	
	tmp = CTmp.new();
	
# загрузка данных для сцены 
func load_scene() -> void:
	
	control_1 = CControl.new();
	
	grid = CGrid.new();
	# данные для сцены подгружены
	_is_loaded_scene = true;
	
# процесс работы приложения
func _physics_process(delta: float) -> void:
	
	if true == _is_loaded_scene:
		control_1.process(delta);
	
# пауза
func paused() -> void:
	get_tree().set_pause(
		!is_paused()
		);
		
# на паузе ли проект
func is_paused() -> bool:
	return get_tree().is_paused();
	

# смена сцены
func change_scene(scene: String) -> void:
	
	_is_loaded_scene = false;
	
	var _error = get_tree().change_scene(scene);
	
# получить данные из темпа
func get_from_tmp(_param: String, _default: String = "") -> String:
	
	return tmp.get_value(_param, _default);
	
# сохраняем данные в темпе
func save_in_tmp(_param: String, _value: String) -> void:
	tmp.set_value(_param, _value )

# получить текущую сцену 
func get_scene() -> Node:
	return get_tree().get_current_scene();
	
# выход из игры
func quit() -> void:
	get_tree().quit();
	
	

	


