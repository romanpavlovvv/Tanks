class_name CControl


# список сущностей, на котрые может влиять управление
var _entities: Dictionary ={};

# текущая сущность для манипуляции, манипуляции ведутся с последним элементом массва
var _current_entities: Array = [];

# потоки
var _threads: Dictionary = {};

# метод позваоляет мониторить какие либо изменения раз в кадр
func process(delta: float) -> void:
	if true == has_current_entity():
		
		var _actions = get_current_entity().actions;
		
		if true == _actions.has_current_action():
			_actions.get_current_action().process(delta);
			
			
		else:
			for _thread in _threads[get_current_entity_name()]:
				_thread.process(delta);
			
					
# метод позволяет запомнить сущность в справочнике сущностей
func set_entity(
	name: String,
	entity: Object,
	threads: Array,
	current: bool = false
) -> void:
	if false == _entities.has(name):
		_entities[name] = entity;
		
	# если нет потоков у сущности
	if false == _threads.has(name):
		_threads[name] = [];
		
		var _number: int = 0;
		
		for _rules in threads:
			# регестрируем поток у сущности 
			_threads[name].append(CThread.new(_number, _rules, entity));
		
			_number += 1;
	# если сущность необходимо отлавить в стек 
	if true == current:
		set_current_entity(name);
		
		
# передаем управление говой сущности 
func set_current_entity(name: String) -> void:
	# переменная для правил 
	var _rule: CControlRule;
	
	# если есть текущая сущность 
	if true == has_current_entity():
		for _thread in _threads[get_current_entity_name()]:
			for _action in get_current_entity().actions.get_current_actions(_thread.get_number()):
				_rule = _thread.get_current_rule(_action.get_name());
				
				# есть клавиша завершения
				if true ==_rule.is_end_key():
					get_current_entity().action.end_action(_action.get_name());
		
		
		
	# передаем управление новой сущности
	_current_entities.append(name);
	
# существует ли текущая сущность 
func has_current_entity() -> bool:
	return false == _current_entities.empty();
	
# закрыть текущую сущность, передать управление предыдущей сущности 
func close_current_entity() -> void:
	_current_entities.pop_back();

# метод возвращает имя текущей сущности
func get_current_entity_name() -> String:
	return _current_entities.back();
	
# метод возвращает текущую сущность 
func get_current_entity() -> Node:
	return _entities[get_current_entity_name()];
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
