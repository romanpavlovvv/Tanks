class_name CGrid

# объект AStar
var _astar: AStar

var _grid_size: Dictionary = {
	"x": 13,
	"z":13
};

var _grid: Array;

# типы точек на карте с информацией
enum{
	_EMPTY = -1,
	_POINT = 0,
	_RESPAWN = 1,
	_BASE = 2,
	_PLAYER_1 = 3,
	_PLAYER_2 = 4,
	_BONUS = 5,
};

func load_grid() -> void:
	
	#формируем сетку
	_get_grid();
	# формируем информацию для AStar
	_get_astar();
	
	
# получить сетку
func _get_grid() -> void:
	# карта
	var _map = CApp.get_scene().get_node("Map/GridMap");
	# стартовая точка
	var _start: Vector3 = CApp.get_scene().get_node("Map/Start").global_translation;
	
	var _cols: Array = [];
	
	var _rows: Array = [];
	
	var _vector: Vector3;
	# id для переноса в AStar
	var _id = 1;
	
	while _rows.size() < _grid_size.z:
		_cols = [];
		
		
		while _cols.size() < _grid_size.x:
			_vector = _start + Vector3(
				_cols.size() * _map.cell_size.x, 
				0, 
				_rows.size() * _map.cell_size.z);
			
			_cols.append(
				{
					# id для AStar
					"id": _id,
					# тип точки на карте
					"type": _map.get_cell_item(
						int(_map.world_to_map(_vector).x), 
						int(_map.world_to_map(_vector).y), 
						int(_map.world_to_map(_vector).z)
					),
					# координаты клетки
					"vector": _vector,
					# номер строки
					"row": _rows.size(),
					# номер колонки
					"col": _cols.size()
				});
				
			# переключаем id для AStar
			_id += 1;
		# запонимаем колонку в строке
		_rows.append(_cols)	
	# сохраняем собранную сетку
	_grid = _rows;
	
	_map.visible = false;
	
# формируем AStar	
func _get_astar() -> void:
	
	_astar = AStar.new();
	
	for _col in _grid_size.x:
		
		for _row in _grid_size.z:
			
			if (
					_grid[_row][_col].type != _EMPTY
				&&	_grid[_row][_col].type != _PLAYER_1
				&&	_grid[_row][_col].type != _PLAYER_2
			):
					# регистрируем точку
					_astar.add_point(_grid[_row][_col].id, _grid[_row][_col].vector);
				
	
	for _col in _grid_size.x:
		
		for _row in _grid_size.z:
			
			if false == _astar.has_point(_grid[_row][_col].id):
				
				continue;
				
			if(
					_col != _grid_size.x - 1
				&&	true == _astar.has_point(_grid[_row][_col + 1].id)
			):
				# соединяем клетки
				_astar.connect_points(
					_grid[_row][_col].id,
					_grid[_row][_col + 1].id
				);
			
			
			if(
					_row != _grid_size.z - 1
				&&	true == _astar.has_point(_grid[_row + 1][_col].id)
			):
				# соединяем клетки
				_astar.connect_points(
					_grid[_row][_col].id,
					_grid[_row + 1][_col].id
				);

func get_grid_size() -> Dictionary:
	return _grid_size;

func get_grid() -> Array:
	return _grid;
	
func get_astar() -> AStar:
	return _astar;

# существует ли клетка в AStar
func has_cell_by_position(_position: Vector3) -> bool:
	return false == get_cell_by_position(_position).empty();
	
# получаем клетку по координатам
func get_cell_by_position(_position: Vector3) -> Dictionary:
	
	for _row in _grid.size():
		
		for _col in _grid[_row].size():
			
			if _position.distance_to(_grid[_row][_col].vector) == 0:
				
				if _astar.has_point(_grid[_row][_col].id):
					
					return _grid[_row][_col];
	
	return {};
	
# получаем клетку по типу 
func get_cell_by_type(type: int, _slice: int = 1) -> Dictionary:
	
	var _collect: Array = [];
	
	for _row in _grid.size():
		
		for _col in _grid[_row].size():
			
			if _grid[_row][_col].type == type:
				
				_collect.append(_grid[_row][_col]);
				
				
	if _slice == 0 && _collect.size() > 0:
		_slice = randi() % _collect.size() + 1;

	return _collect[_slice - 1] if _collect.size() > 0 else {};

func is_node_in_cell(_node: Node, _cell: Dictionary) -> bool:
	
	if null == _node:
		
		return false;
		
	return _node.global_translation.distance_to(_cell.vector) < get_cell_size().x;


func get_cell_size() -> Vector3:
	return CApp.get_scene().get_node("Map/GridMap").cell_size; 
