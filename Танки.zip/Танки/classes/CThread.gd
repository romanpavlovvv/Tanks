class_name CThread

# в процессе ли поток
var _is_processed: bool = false;

# правила сущности
var _rules: Array;
# сушность 
var _entity: Object;

# номер потока
var _number: int;

# поднять объект
func _init(number: int,rules: Array, entity: Object) -> void:
	_rules = rules;
	_number = number;
	_entity = entity;
	
	for _rule in rules:
		# делимся информацией о потоках с механизмом действий
		_entity.actions.set_thread_action(_number, _rule.get_name());
	
	
	
	
# процесс потока
func process(delta: float) -> void:
	
	if true == _is_processed:
		print("CThread ERROR");
		
	# фиксируем запуск потока
	_is_processed = true;
	
	var _actions = _entity.actions;
	
	if false == _actions.has_current_action(_number):
		
		for _rule in _rules:
			# есть ли клавиша старта у правила и нажата ли она 
			if (_rule.is_start_key() && Input.is_action_pressed(_rule.get_start_key())):
				# запускаем действие
				_actions.set_current_action(_rule.get_name(), delta, _number);
				
				# запускаем процесс 
				_actions.get_current_action(_number).process(delta);
	else:
		for _permissible in get_current_rule(_actions.get_current_action(_number).get_name()).get_allowed_actions():
			# если у одного из них есть клавиша старта и она нажата
			if (get_current_rule(_permissible).is_start_key() && Input.is_action_pressed(get_current_rule(_permissible).get_start_key())):
				# запускаем под действие
				_actions.set_current_action(_permissible, delta, _number);
		
		# запускаем процесс
		_actions.get_current_action(_number).process(delta);
	
	# мониторинг окончания действий
	for _action in _actions.get_current_actions(_number):
		if false == get_current_rule(_action.get_name()).is_end_key():
			if true == _action.is_timer_out():
				# замершаем действие
				_actions.end_action(_action.get_name());
		
		elif Input.is_action_just_released(get_current_rule(_action.get_name()).get_end_key()):
			# завершаем действие 
			_actions.end_action(_action.get_name());
	
	
	# завершаем процесс
	_is_processed = false;
	
	
# метод возвращает текущий набор правил
func get_current_rules() -> Array:
	return _rules;
	
# есть ли правило текущей сущности (по имени)
func is_current_rule(name: String) -> bool:
	return null != get_current_rule(name);
	
# получаем правило текущей сущности по имени
func get_current_rule(name: String) -> CControlRule:
	
	for _rule in get_current_rules():
		if _rule.get_name() == name:
			return _rule;
			
	
	return null;


# получить номер потока
func get_number() -> int:
	return _number;

