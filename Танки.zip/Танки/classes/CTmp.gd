class_name CTmp

var _buffer: Dictionary;

func get_value(path: String, default: String) -> String:
	
	var group = path.split(".")[0];
	
	var param = path.split(".")[1];
	
	if false == _buffer.has(group):
		return default;
		
	if false == _buffer.has(param):
		return default;
	
	return _buffer.get(group).get(param);

func set_value(path: String, value: String) -> void:
	
	var group = path.split(".")[0];
	
	var param = path.split(".")[1];
	
	if false == _buffer.has(group):
		_buffer[group] = {};
	
	_buffer[group][param] = value;
		
	
func destroy_value(path: String) -> void:
	var group = path.split(".")[0];
	
	var param = path.split(".")[1];
	
	if false == _buffer.has(group):
		return;
		
	if false == _buffer[group].has(param):
		return;
	

func clear_buffer() -> void:
	_buffer = {};
