extends CActionBase

class_name CActionsAmmunitionGo

var _timer: float;

var _vector: Vector3;

var _delta: float;

var _is_colliding: KinematicCollision;

func _init(name: String, timer: float).(name) -> void:
	_timer = timer;

func run(delta: float) -> void:
	
	_vector = _entity.global_transform.basis.z;
	
	start_timer(_timer)
	
	_delta = delta;


func process(delta: float) -> void:
	
	
	_is_colliding = _entity.move_and_collide(
		Vector3(
			delta *(_vector.x * -1) * _entity.speed,
			0,
			delta *(_vector.z * -1)* _entity.speed
			)
	);
			
	
	.process(delta);
	
	if is_timer_out() || null != _is_colliding:
		_entity.actions.end_action(get_name());
		

func end() -> void:
	
	.end();
	
	if (null != _is_colliding && _is_colliding.collider.has_method("make_damage")):
		_is_colliding.collider.make_damage(_entity.who, _delta);
	
	
	
	_entity.queue_free();
