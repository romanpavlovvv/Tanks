extends CActionBase

class_name CActionsBaseDestroy


func _init(name: String).(name) -> void:
	pass;
	
	
	
# первичный запуск действия
func run(_delta: float) -> void:
	start_timer(1.5);
	
	var _parts = load("res://assets/scenes/particles/Base.tscn").instance();
	
	_parts.visible = true;
	# даем конкретное название
	_parts.set_name("Parts");
	# загружаем на сцену 
	_entity.add_child(_parts);
	
	# отключаем коллизию
	_entity.get_node("CollisionShape").disabled = true;
	
	_entity.get_node("base").visible = false;
	
	# запускает скрипт разрушения
	_entity.get_node("Parts").destroy();
	
	
# процесс действия
func process(delta: float) -> void:
	
	.process(delta);
	
	if is_timer_out():
		_entity.actions.end_action(get_name());
	
	
	
# окончание действия
func end() -> void: 
	
	.end();
	
	_entity.queue_free();
