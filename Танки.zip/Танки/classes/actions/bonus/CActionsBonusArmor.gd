extends CActionBase

class_name CActionsBonusArmor

func _init(name: String).(name) -> void:
	
	pass
	
func run(_delta: float) -> void:
	
	start_timer(_entity.timer);
	
	_entity.get_player().armor = true;
	
	_entity.get_player().get_node("Flag_Red").visible = true;
	
func process(delta: float) -> void:
	
	.process(delta);
	
	if is_timer_out():
		
		_entity.actions.end_action(get_name());
		
func end() -> void:
	
	.end();
	
	_entity.get_player().armor = false;
	
	_entity.get_player().get_node("Flag_Red").visible = false;
	
	_entity.deactivate();
	
