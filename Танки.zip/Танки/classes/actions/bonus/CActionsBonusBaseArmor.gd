extends CActionBase

class_name CActionsBonusBaseArmor

func _init(name: String).(name) -> void:
	
	pass
	
func run(_delta: float) -> void:
	
	start_timer(_entity.timer);
	
	CApp.get_scene().get_node("Map/Base/Unarmored").visible = false;
	
	for _wall in CApp.get_scene().get_node("Map/Base/Unarmored").get_children():
		
		_wall.set_collision_layer_bit(0, false);
		
		
	for _npc in CApp.get_scene().get_enemies():
		
		if true == _npc.in_death_zone:
			
			_npc.actions.set_current_action("destroy", _delta);
			
			
			
	for _player in CApp.get_scene().get_players():
		
		if true == _player.in_death_zone:
			
			_player.set_hp(1);
			
			_player.actions.end_all_actions();
			
			_player.actions.set_current_action("destroy", _delta);
		
		
	CApp.get_scene().get_node("Map/Base/Armored").visible = true;
	
	for _wall in CApp.get_scene().get_node("Map/Base/Armored").get_children():
		_wall.set_collision_layer_bit(0, true);
		
	
func process(delta: float) -> void:
	
	.process(delta);
	
	if is_timer_out():
		
		_entity.actions.end_action(get_name());
		
func end() -> void:
	
	.end();
	
	CApp.get_scene().get_node("Map/Base/Armored").visible = false;
	
	for _wall in CApp.get_scene().get_node("Map/Base/Armored").get_children():
		
		_wall.set_collision_layer_bit(0, false);
		
		
	CApp.get_scene().get_node("Map/Base/Unarmored").visible = true;
	
	for _wall in CApp.get_scene().get_node("Map/Base/Unarmored").get_children():
		
		_wall.set_collision_layer_bit(0, true);
		
	
	_entity.deactivate();
	
	

	
