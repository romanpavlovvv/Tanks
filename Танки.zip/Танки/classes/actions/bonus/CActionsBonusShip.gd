extends CActionBase

class_name CActionsBonusShip

func _init(name: String).(name) -> void:
	pass;
	
func run(_delta: float) -> void:
	
	_entity.get_player().ship = true;
	
	_entity.get_player().get_node("Flag_Blue").visible = true;
	
	
	_entity.get_player().set_collision_mask_bit(7, false);
	 
func process(delta: float) -> void:
	
	.process(delta);
	
	if(false == _entity.get_player().ship && false == _entity.get_player().is_in_water()):
		
		_entity.actions.end_action(get_name());
	
	
func end() -> void:
	
	.end();
	
	_entity.get_player().get_node("Flag_Blue").visible = false;
	
	_entity.get_player().set_collision_mask_bit(7, true);
	
	_entity.deactivate();
