extends CActionBase

class_name CActionsBonusTime

func _init(name: String).(name) -> void:
	pass;
	
func run(_delta: float) -> void:
	
	start_timer(_entity.timer);
	
func process(delta: float) -> void:
	
	.process(delta);
	
	if is_timer_out():
		
		_entity.actions.end_action(get_name());
		

func end() -> void:
	
	.end();
	
	_entity.deactivate();
