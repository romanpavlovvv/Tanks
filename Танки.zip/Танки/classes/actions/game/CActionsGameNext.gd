extends CActionBase

class_name CActionsGameNext


func _init(name: String).(name) -> void:
	pass
	
func end() -> void:
	
	.end();
	
	var _level = int(CApp.get_scene().get_name().split("_")[1]);
	
	var _file = File.new();
	
	if _file.file_exists(
		"res://assets/scenes/locations/Level_" + String(_level + 1) + ".tscn"
		):
		CApp.change_scene("res://assets/scenes/locations/Level_" + String(_level + 1) + ".tscn")	
		
		
	else:
		CApp.change_scene("res://assets/scenes/locations/Level_1.tscn")
