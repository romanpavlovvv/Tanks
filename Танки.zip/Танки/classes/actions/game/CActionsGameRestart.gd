extends CActionBase

class_name CActionsGameRestart

func _init(name: String).(name) -> void:
	pass
	
func end() -> void:
	
	.end();
	
	CApp.tmp.clear_buffer();
	
	CApp.change_scene("res://assets/scenes/locations/MainMenu.tscn");

