extends CActionBase

class_name CActionsMenuGo

var _direction: String;


func _init(name: String, direction).(name) -> void:
	_direction = direction;
	

func run(delta: float) -> void:

	pass;


func end() -> void:
	
	var _button = _entity.menu.get_current_button();
	
	_entity.menu.deactivate(_button);
	
	match (_direction):
		"up":
			_entity.menu.activate(_entity.menu.get_previous(_button));
			
		"down":
			_entity.menu.activate(_entity.menu.get_next(_button));
			
			
	.end();

