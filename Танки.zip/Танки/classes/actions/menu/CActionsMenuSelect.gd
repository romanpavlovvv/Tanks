extends CActionBase

class_name CActionsMenuSelect


func _init(name: String).(name) -> void:
	
	pass;
	

func run(_delta: float) -> void:
	
	pass;
	
	
func end() -> void:
	
	_entity.menu.select()
	
	.end();

