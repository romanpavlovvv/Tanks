extends CActionBase

class_name CActionsNPCLoad


func _init(name: String).(name) -> void:
	pass
	
func run(_delta: float) -> void:
	
	start_timer(0.5);
	
	var _tank: Dictionary =  _entity.get_next_tank();
	
	var _npc = load(
	"res://assets/scenes/nps/NPC_"+ _tank.type + ".tscn"
	).instance();
	
	match _tank.type:
		"1","2":
			_npc.speed  = 3;
			
			_npc.score = 100 if _tank.type == "1" else 300
			
		_:
			_npc.speed  = 2;
			
			_npc.score = 400;
	
	_npc.hp = int(_tank.type);
	
	_npc.type = int(_tank.type);
	
	
	_npc.respawn_point = CApp.grid.get_cell_by_type(
		CApp.grid._RESPAWN, _tank.respawn
	).vector;
	
	
	_npc.set_translation(_npc.respawn_point - Vector3(0, 0, 2 * CApp.grid.get_cell_size().z));
	
	_npc.rotation.y = -PI;
	
	_npc.add_to_group("NPC"); 
	
	CApp.get_scene().add_child(_npc);
	
	
func process(delta: float) -> void:
	
	.process(delta);
		
	if is_timer_out():
		_entity.actions.end_action(get_name());
