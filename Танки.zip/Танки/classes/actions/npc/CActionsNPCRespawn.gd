extends CActionBase

class_name CActionsNPCRespawn

func _init(name: String).(name) -> void:
	pass
	

func process (delta: float) -> void:
	
	# получаем дистанцию что танк проедет за кадр
	var _distance = delta * _entity.speed;
	
	# дистанция до респа
	var _distance_to = _entity.global_translation.distance_to(_entity.respawn_point);
	
	if _distance_to < _distance:
		_entity.global_translation = _entity.respawn_point;
		
		_entity.set_collision_mask_bit(0, true);
		
		_entity.actions.end_action(get_name());
	
	else:
		_entity.move_and_collide( Vector3(0, 0, _distance));
	
	.process(delta);

