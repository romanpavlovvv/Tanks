extends CActionBase

class_name CActionsNPCShot

var _shell: KinematicBody;

var _valid: bool = false;


func _init(name: String).(name) -> void:
	pass
	

func run(_delta: float) -> void:
	
	start_timer(10);
	
	_shell = load("res://assets/scenes/ammunition/Shell_NPC.tscn").instance();
	
	_shell.global_transform = _entity.get_node("Gun").global_transform;
	
	_shell.who = _entity;
	
	_valid = true;
	
	CApp.get_scene().add_child(_shell)
	
	
	
func process(delta: float) -> void:
	
	if null != CApp.get_scene().get_active_bonus_by_type(CBonus._TIME):

		return;	
	
	.process(delta);
	
	
	if true == _valid && false == is_instance_valid(_shell):
		
		start_timer(0.5);
		
		_valid = false;
		
	if is_timer_out():
		_entity.actions.end_action(get_name());
