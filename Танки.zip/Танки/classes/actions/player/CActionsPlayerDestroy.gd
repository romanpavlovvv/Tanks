extends CActionBase

class_name CActionsPlayerDestroy

var _delta: float;


func _init(name: String).(name) -> void:
	pass
	
# пер
func run(delta: float) -> void:
	
	_delta = delta
	start_timer(1.5);
	
	var _parts = load("res://assets/scenes/particles/Parts.tscn").instance();
	
	_parts.visible = true;
	# даем конкретное название
	_parts.set_name("Parts");
	# загружаем на сцену 
	_entity.add_child(_parts);	
	# отключаем коллизию
	_entity.get_node("CollisionShape").disabled = true;
	# отключаем реакцию на мир
	_entity.set_collision_mask_bit(0, false);
	# уничтожаем модель танка
	_entity.get_node("Tank").queue_free();
	
	_entity.get_node("Parts").destroy();
	

func process (delta: float) -> void:
	
	.process(delta);
	
	if is_timer_out():
		_entity.actions.end_action(get_name());
	
func end() -> void:
	
	.end();
	
	_entity.get_node("Parts").free();
	
	# точка респа
	var _respawn_point = (
		CApp.grid.get_cell_by_type(CApp.grid._PLAYER_1).vector
	);
	
	# двигаю танк в ангар
	_respawn_point =  _respawn_point + Vector3(0, 0, 2 * CApp.grid.get_cell_size().z);
	
	_entity.global_translation = _respawn_point;
	
	_entity.set_lives(_entity.lives - 1);
	
	_entity.set_lives_in_ui();
   
	if _entity.lives > 0:
		_entity.actions.set_current_action("respawn", _delta);
		
	else:
		print("Game over")
