extends CActionBase

class_name CActionsPlayerGo

var _direction: String;

var _delta: float;


func _init(name: String, direction: String).(name) -> void:
	_direction = direction;
	

# первичное действие
# warning-ignore:shadowed_variable
func run(_delta: float) -> void:
	# ротация
	match _direction:
		"left":
			_entity.rotation.y = PI/2;
		"right":
			_entity.rotation.y = -PI/2;
		"up":
			_entity.rotation.y = 0;
		"down":
			_entity.rotation.y = -PI;
		
	
	
# процесс действия
func process(delta: float) -> void:
	
	var _is_colliding: KinematicCollision;
	
	match _direction:
		"left":
			_is_colliding = _entity.move_and_collide(Vector3(-delta * _entity.speed, 0, 0));
		"right":
			_is_colliding = _entity.move_and_collide(Vector3(delta * _entity.speed, 0, 0));
		"up":
			_is_colliding = _entity.move_and_collide(Vector3(0, 0 , -delta * _entity.speed));
		"down":
			_is_colliding = _entity.move_and_collide(Vector3(0, 0 , delta * _entity.speed));
			
	_delta = delta;
	
	.process(delta);
	

	
	
func end() -> void:
	
	.end();
	
	if true == _entity.is_on_ice():
		_entity.actions.set_current_action("slip",_delta);
		
	
	
	
	
	
	
	
	
