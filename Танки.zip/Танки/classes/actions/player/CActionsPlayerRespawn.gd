extends CActionBase

class_name CActionsPlayerRespawn

func _init(name: String).(name) -> void:
	pass
	

func run(_delta: float) -> void:
	
	_entity.get_node("CollisionShape").disabled = false;
	
	_entity.rotation.y = 0;
	
	_entity.update();
	

func process (delta: float) -> void:
	# точка респа
	var _respawn_point = (
		CApp.grid.get_cell_by_type(CApp.grid._PLAYER_1).vector
	);
	
	# получаем дистанцию что танк проедет за кадр
	var _distance = delta * _entity.speed;
	
	# дистанция до респа
	var _distance_to = _entity.global_translation.distance_to(_respawn_point);
	
	if _distance_to < _distance:
		_entity.global_translation = _respawn_point;
		
		_entity.set_collision_mask_bit(0, true);
		
		_entity.actions.end_action(get_name());
	
	else:
		_entity.move_and_collide( Vector3(0, 0, -_distance)
		);
	
	.process(delta);

	
func end() -> void:
	
	.end();

   
