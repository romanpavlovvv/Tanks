extends CActionBase

class_name CActionsPlayerShot

# снаряд
var _shell: KinematicBody;

# валидный ли снаряд
var _valid: bool = false;

func _init(name: String).(name) -> void:
	pass
	
# пер
func run(_delta: float) -> void:
	
	start_timer(10);
	_shell = load ("res://assets/scenes/ammunition/Shell_Player.tscn").instance();
	
	_shell.global_transform = _entity.get_node("Gun").global_transform;
	
	_shell.who = _entity;
	
	_valid = true;
	
	CApp.get_scene().add_child(_shell);


func process (delta: float) -> void:
	
	.process(delta);
	
	if true == _valid && false == is_instance_valid(_shell):
		start_timer(0.2);
		
		_valid = false;
		
