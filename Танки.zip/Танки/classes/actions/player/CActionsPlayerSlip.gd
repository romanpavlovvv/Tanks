extends CActionBase

class_name CActionsPlayerSlip

var _direction: String;

func _init(name: String).(name) -> void:
	pass
	

func run(_delta: float) -> void:
	
	var _vector = _entity.global_transform.basis.z;
	
	if int(_vector.z) == 0:
		_direction = "right" if _vector.x == -1 else "left";
		
	elif int(_vector.x) == 0:
		_direction = "down" if _vector.z == -1 else "up";
	
	
	# таймер для скольжения
	start_timer(0.3);


func process (delta: float) -> void:
	
	.process(delta);
	
	match _direction:
		"left":
			_entity.move_and_collide(Vector3(-delta * _entity.speed, 0, 0));
		"right":
			_entity.move_and_collide(Vector3(delta * _entity.speed, 0, 0));
		"up":
			_entity.move_and_collide(Vector3(0, 0 , -delta * _entity.speed));
		"down":
			_entity.move_and_collide(Vector3(0, 0 , delta * _entity.speed));
			
	
	if is_timer_out():
		_entity.actions.end_action(get_name());
	
func end() -> void: 
	
	.end();
	
