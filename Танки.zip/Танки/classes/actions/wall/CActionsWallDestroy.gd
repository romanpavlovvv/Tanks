extends CActionBase

class_name CActionsWallDestroy


func _init(name: String).(name) -> void:
	pass;
	
	
	
# первичный запуск действия
func run(_delta: float) -> void:
	start_timer(1.5);
	
	var _parts = load("res://assets/scenes/particles/Bricks.tscn").instance();
	
	_parts.visible = true;
	# даем конкретное название
	_parts.set_name("Bricks");
	# загружаем на сцену 
	_entity.add_child(_parts);
	
	# отключаем коллизию
	_entity.get_node("CollisionShape").disabled = true;
	
	_entity.get_node("wall_1").visible = false;
	
	# запускает скрипт разрушения
	_entity.get_node("Bricks").destroy();
	
	
# процесс действия
func process(delta: float) -> void:
	
	.process(delta);
	
	if is_timer_out():
		_entity.actions.end_action(get_name());
	
	
	
# окончание действия
func end() -> void: 
	
	.end();
	
	_entity.queue_free();
