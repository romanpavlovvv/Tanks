extends CActionBase

class_name CActionsWindowClose

var _window: Node;

func _init(name: String, window: Node).(name) -> void:
	_window = window;
	
	

# окончание действия
func end() -> void: 
	
	.end();
	
	if true == CApp.is_paused():
		
		CApp.paused();
	
	_window.close();
	
	
