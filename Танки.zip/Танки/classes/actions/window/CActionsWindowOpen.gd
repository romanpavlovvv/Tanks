extends CActionBase

class_name CActionsWindowOpen

var _window: Node;

func _init(name: String, window: Node).(name) -> void:
	_window = window;
	
	

# окончание действия
func end() -> void: 
	
	.end();
	
	if false == CApp.is_paused():
		CApp.paused();
	
	_window.open();
	
	
