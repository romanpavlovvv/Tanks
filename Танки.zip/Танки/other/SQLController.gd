extends Control

var database: SQLiteWrapper

func _ready():
	
	database = SQLiteWrapper.new();
	database.path = "res://data.db";
	database.open_db();

func _process(delta):
	pass;

func _on_CreateTable_button_down():
	
	var table = {
		"id" : {"data_type": "int", "primary_key": true, "not_null": true, " auo_increment"}
	}
	pass 


func _on_Button_button_down():
	pass # Replace with function body.
