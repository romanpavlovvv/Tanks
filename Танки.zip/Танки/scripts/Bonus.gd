extends Area

class_name CBonus

enum {
	_UPGRADE = 0,
	_LIFE = 1,
	_TIME = 2,
	_DESTROY = 3,
	_BASE_ARMOR = 4,
	_SHIP = 5,
	_ARMOR = 6
};

var _type: int;

var _delta: float;

var actions: CActions;

var _player: KinematicBody;

var score: int = 200;


func _ready():
	
	actions = CActions.new(self);
	
	var _error = connect("body_entered", self, "_on_body_entered");
	
	
func _physics_process(delta: float) -> void:
	 
	_delta = delta;
	
	if actions.has_current_action():
		
		actions.get_current_action().process(delta);
		
func activate() -> void:
	
	get_node("CollisionShape").disabled = true;
	
	visible = false
	
	_player.save_score(self);
	
func deactivate() -> void:
	
	queue_free();
	
func set_type(type: int) -> void:
	
	 _type = type;
	

func get_type() -> int: 
	return _type;
	
	
func set_player(player:KinematicBody) -> void:
	_player = player;
	
	
func get_player() -> KinematicBody:
	
	return _player;
	
func _get_similar_bonus(_by_player: bool = true) -> Node:
	
	for _child in CApp.get_tree().get_nodes_in_group("Bonuses"):
		
		if( _child != self && _child.get_type() == get_type() && (false == _by_player || _child.get_player() == get_player())):
			
			return _child;
		
	return null;
	
func _on_body_entered(player: Node) -> void:
	
	set_player(player);
	
	activate();
	
	
	
	
	
	
	
	
