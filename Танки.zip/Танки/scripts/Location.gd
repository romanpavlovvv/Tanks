extends Spatial

export var respawn_1: String;

export var respawn_2: String;

export var respawn_3: String;

var respawns: Array;

var actions: CActions;

var _bonuses: Array =[
	"Upgrade",
	"Life",
	"Time",
	"Destroy",
	"Base_Armor",
	"Ship",
	"Armor"
]

func _init():
	CApp.load_scene();

func _ready():	
	
	if true == CApp.is_paused():
		CApp.paused();
	
	CApp.grid.load_grid();
	
	# заполняем ангары танками
	respawns.append(get_respawn_data(respawn_1));
	respawns.append(get_respawn_data(respawn_2));
	respawns.append(get_respawn_data(respawn_3));
	
	actions = CActions.new(self);
	
	actions.set_action(CActionsNPCLoad.new('load'));
	
	get_node("Map/Base/Armored").visible = false;
	
	for _wall in get_node("Map/Base/Armored").get_children():
		_wall.set_collision_layer_bit(0, false);
	

func _physics_process(delta: float) -> void:
	
			
	if false == actions.has_current_action():
		if true  == is_revive_tank():
			actions.set_current_action("load", delta);
			actions.get_current_action().process(delta);
		
	else:
		actions.get_current_action().process(delta);
	
	if is_game_over():
		game_over(delta);
		
	
	
	elif is_next_level():
		next_level(delta);
		
	
	
func get_respawn_data(string: String) -> Array:
	return 	Array(string.split(",")) if string != "" else [];
	

func is_revive_tank() -> bool:
	if true == respawns_empty():
		return false;
	
	return get_enemies().size() < 3;
	
func respawns_empty() -> bool:
	return respawns[0].size() == 0 && respawns[1].size() == 0 && respawns[2].size() == 0;
	
	

func has_enemies() -> bool:
	
	return false == get_enemies().empty();
	
func get_enemies() -> Array:
	return CApp.get_tree().get_nodes_in_group("NPC");
	
func get_players() -> Array:
	return CApp.get_tree().get_nodes_in_group("Players");
	
	
func get_next_tank() -> Dictionary:
	
	var _respawn: Dictionary;
	
	for i in respawns.size():
		if _respawn.size() == 0 || _respawn.get("count") < respawns[i].size():
			_respawn = {
				"key": i,
				"respawn": i + 1,
				"count": respawns[i].size(),
			}
	
	
	return {
		"type": respawns[_respawn.get("key")].pop_back(),
		"respawn": _respawn.get("respawn")
	};

func get_active_bonus_by_type(type: int) -> Node:
	
	for _child in CApp.get_tree().get_nodes_in_group("Bonuses"):
		
		if _child.get_type() == type && null != _child.get_player():
			
			return _child;
	
	
	return null;
	
func get_not_active_bonuses() -> Array:
	
	var collect: Array = [];
	
	for _child in CApp.get_tree().get_nodes_in_group("Bonuses"):
		
		if null == _child.get_player():
			pass;
	
	return collect;
	
func generate_bonus() -> void:
	
	var _bonus: Node;
	
	var _cell: Dictionary;
	
	var _type = randi() % 7;
	
	var players = get_players();
	
	for _node in get_not_active_bonuses():
		
		_node.free();
		
	while true:
		
		_cell = CApp.grid.get_cell_by_type(CApp.grid._BONUS, 0);
		
		if( false == CApp.grid.is_node_in_cell(players[0], _cell)):
			break;
			
	_bonus = load(
		"res://assets/scenes/bonuses/" + _bonuses[_type] + ".tscn"
		).instance();
	
	_bonus.set_translation(_cell.vector);
	
	_bonus.add_to_group("Bonuses");
	
	add_child(_bonus);
	
func is_next_level() -> bool:
	
	return false == has_enemies() && true == respawns_empty();

func is_game_over() -> bool:
	
	if CApp.get_scene().get_node("Player_1").lives == 0:
		return true;	
	
	if !CApp.get_scene().has_node("Map/Base/Eagle"):
		return true;
	
	return false;
	
func game_over(delta: float) -> void:
	CApp.get_scene().get_node("Player_1").actions.end_all_actions();
	
	CApp.control_1.get_current_entity().actions.set_current_action("gameover", delta);
	
	CApp.control_1.get_current_entity().actions.end_action("gameover");
	
func next_level(delta: float) -> void:
	CApp.get_scene().get_node("Player_1").actions.end_all_actions();
	
	CApp.control_1.get_current_entity().actions.set_current_action("congratulation", delta);
	
	CApp.control_1.get_current_entity().actions.end_action("congratulation");
	
	
func scoring(_win: Node) -> void:
	for player in get_players():
		
		player.scoring(_win);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
