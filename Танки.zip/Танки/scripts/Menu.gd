extends Node


export(String) var entity_name;

var actions: CActions

func _ready() -> void:
	
	actions = CActions.new(self);
	
	
	actions.set_action(CActionsMenuGo.new("up", "up"));
	
	actions.set_action(CActionsMenuGo.new("down", "down"));
	
	actions.set_action(CActionsMenuSelect.new("select"));

	CApp.control_1.set_entity(entity_name, self, [
		[
			CControlRule.new("up", "ui_player_1_up", "ui_player_1_up"),
			CControlRule.new("down", "ui_player_1_down", "ui_player_1_down"),
			CControlRule.new("select", "ui_accept", "ui_accept")
		]
	], true);
	
	deactivate();
	
	get_children()[0].activate();
	

func get_current_button() -> Node:
	for _button in get_children():
		if true == _button.is_active():
			return _button;
			
	return null;


func deactivate() -> void: 
	
	for _button in get_children():
		
		_button.deactivate();
