extends KinematicBody


var speed: float = 3;

var hp: int = 1;

var type: int = 1;

var _first_frame: bool = true;

var in_death_zone: bool = false;

var _is_bonus: bool;

var score: int;
 
var actions: CActions;

var respawn_point: Vector3;


func _ready() -> void:
	
	# поднимаем механизм действий
	actions = CActions.new(self);
	
	
	actions.set_action(CActionsNPCShot.new("shot"));
	
	actions.set_action(CActionsNPCGo.new("go"));

	actions.set_action(CActionsNPCDestroy.new("destroy"));

	actions.set_action(CActionsNPCRespawn.new("respawn"));
	
	# регаем действие "ездить" в потоке ноль
	actions.set_thread_action(0, "go");
	
	actions.set_thread_action(0, "respawn");
	# регаем действие "стрелять" в потоке один
	actions.set_thread_action(1, "shot");
	
	
	if randi() % 100 < 50:
		
		_is_bonus = true;
		
	else:
		
		get_node("Flag").visible = false;
		
		_is_bonus = false;
	

func _physics_process(delta: float) -> void:
	 
	if true == _first_frame:
		
		actions.set_current_action("respawn", delta, 0);
		
		actions.get_current_action(0).process(delta);
			
		_first_frame = false;
		
		return;
	
	
	if true == actions.has_current_action():
		# исполняем его
		actions.get_current_action().process(delta);
		# обрываем _physics_process
		return;
	
	

	if false == actions.has_current_action(0):
		
		actions.set_current_action("go", delta, 0);
		
		actions.get_current_action(0).process(delta);
		
	else: 
		actions.get_current_action(0).process(delta);
		
		if !actions.has_current_action(1):
			
			actions.set_current_action("shot", delta, 1);
			
		else:
			
			actions.get_current_action(1).process(delta);


func make_damage(player: KinematicBody, delta: float) -> void:
	
	if true == _is_bonus:
		
		CApp.get_scene().generate_bonus();
	
	if hp == 1:
		
		player.save_score(self);
		
		actions.end_all_actions();
		# уничтожить танк
		actions.set_current_action("destroy", delta);

	else:
		hp -= 1;


func where_we_go() -> Dictionary:
	# если понятно где НПС
	if true == CApp.grid.has_cell_by_position(global_translation):
		# получаем его ячйку
		var _from = CApp.grid.get_cell_by_position(global_translation);
		# строка новой точки
		var _row: int;
		# колонка новой точки
		var _col: int;

		# расчитываем строку
		# если смещать некуда
		if _from.row + 2 >= CApp.grid.get_grid_size().z:
			# берем путь к базе
			return CApp.grid.get_cell_by_type(CApp.grid._BASE);
			
		# если есть куда смещать строку
		else:
			# смещаем
			_row = _from.row + 2;

			# бесконечный цикл
			while true:
				# выбераем рандомную колонку
				# от нуля до _grid_size.x
				_col = randi() % CApp.grid.get_grid_size().x;

				# если клетка зарегана
				if CApp.grid.get_astar().has_point(CApp.grid.get_grid()[_row][_col].id):
					# возвращаем информацию о клетке
					return CApp.grid.get_grid()[_row][_col];

	return {};
	
	
