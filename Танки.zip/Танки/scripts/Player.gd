extends KinematicBody

class_name CPlayerBase

var speed: float = 5;

var hp: int = 1;

var lives: int = 3;

var _first_frame: bool = true;

var in_death_zone: bool = false;

var armor: bool = false;

var ship: bool = false;

var actions: CActions;

func ready() -> void:
	
	set_hp(int(CApp.get_from_tmp("player1.hp", "1")));
	
	set_lives(int(CApp.get_from_tmp("player1.lives", "3")));
	
	set_lives_in_ui();
	
	get_node("Flag_Blue").visible = false;
	
	get_node("Flag_Red").visible = false;
	
	add_to_group("Players")
	


func _physics_process(delta: float) -> void:
	
	if true == _first_frame:
		
		if lives > 0:
		
			actions.set_current_action("respawn", delta);
			
		_first_frame = false;
	
func make_damage(_npc: KinematicBody, delta: float) -> void:
	
	if true == armor: 
		return;
		
	if true == ship:
		ship = false;
		
		return;
	
	if hp == 1:
		
		actions.end_all_actions();
		# уничтожить танк
		actions.set_current_action("destroy", delta);
	
	else:
		set_hp(hp - 1);
		
		update();
	

func set_hp(value: int) -> void:
	
	hp = value;
	
	CApp.save_in_tmp("player1.hp", String(hp));


func set_lives(value: int) -> void:
	
	lives = value;
	
	CApp.save_in_tmp("player1.lives", String(lives));


func update() -> void:
	if true == has_node("Tank"):
		get_node("Tank").free();
		
	var _tank = load(
	"res://assets/models/tanks/tank_1_" + String(hp) +  ".tscn"
	).instance();
	
	_tank.set_name("Tank");
	
	add_child(_tank);
		
	

func is_on_ice() -> bool:
	
	for _child in get_node("IceDetectors").get_children():
		if true == _child.is_colliding():
			return true;
			
	
	return false;
	
func is_on_water() -> bool:
	
	for _child in get_node("WaterDetectors").get_children():
		if true == _child.is_colliding():
			return true;
			
	
	return false;
	
func set_lives_in_ui() -> void:
	CApp.get_scene().get_node("Map/UI/Bar/HBoxContainer/Lives").set_text(String(lives));
	
	
func save_score(entity: Node) -> void:
	
	var _score =  load("res://assets/scenes/bonuses/Score.tscn").instance();
	
	_score.get_node("Label").set_text(String(entity.score));
	
	_score.translation = Vector3 (entity.translation.x,0,entity.translation.z);
	
	
	CApp.get_scene().add_child(_score);

	
	var _scores = {
		"npc_1": int(CApp.get_from_tmp("player1" + ".score_1", "0")),
		"npc_2": int(CApp.get_from_tmp("player1" + ".score_2", "0")),
		"npc_3": int(CApp.get_from_tmp("player1" + ".score_3", "0")),
		"bonuses": int(CApp.get_from_tmp("player1" + ".score_bonuses", "0"))
	};

	match(entity.get_class()):
		"KinematicBody":
			CApp.save_in_tmp(
				"player1" + ".score_"+ String(entity.type), 
				String(_scores.get("npc_" + String(entity.type)) + entity.score)
			)
		"Area":
			CApp.save_in_tmp(
				"player1" + ".score_bonuses", 
				String(_scores.get("bonuses") + entity.score)
			);


func scoring(_win: Node) -> void:
	
	var _node = "Player_1";
	
	var _group = "player1";

	var _total = CApp.get_from_tmp(_group + "score_total")
	
	_win.get_node("BG/Total/Bonus/" + _node).set_text(
		CApp.get_from_tmp(_group + ".score_bonuses", "0")
	);
	
	for _n in ["1", "2", "3"]:
		_win.get_node("BG/Total/Statistics/" + _node + "/NPC_" + _n).set_text(
			CApp.get_from_tmp(_group + ".score_" + _n, "0"))
	
	

		










