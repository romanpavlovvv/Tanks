extends Node

class_name CPoint

export(NodePath) var _next;

export(NodePath) var _previous;

var _active: bool = false;

func get_next() -> Node:
	return _next;

func get_previous() -> Node:
	return _previous;

func is_active() -> bool:
	return _active
	
func set_active(value: bool) -> void:
	_active = value;
	
func deactivate() -> void: 
	
	set_active(false);

func activate() -> void:
	set_active(true);
	
func select() -> void:
	print("dsfsdfsdfds" + get_name())

