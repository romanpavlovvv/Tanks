extends KinematicBody

# механизм действий
var actions: CActions;


var speed: float = 10;

var who = KinematicBody;

func _ready() -> void:
	
	actions = CActions.new(self);
	actions.set_action(CActionsAmmunitionGo.new("bullet_flight", 3))
	
func _physics_process(delta: float) -> void:
	
	if false == actions.has_current_action():
		actions.set_current_action("bullet_flight", delta);
		
	actions.get_current_action().process(delta);
   
